function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  
}